rm -f tronsolitare.bin tronsolitare.img

nasm -f bin tronsolitare.asm -o tronsolitare.bin

dd if=/dev/zero of=tronsolitare.img bs=512 count=2880

dd if=tronsolitare.bin of=tronsolitare.img bs=512 count=1 conv=notrunc
