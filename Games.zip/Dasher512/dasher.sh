rm -f dasher.bin dasher.img

nasm -f bin dasher.asm -o dasher.bin

dd if=/dev/zero of=dasher.img bs=512 count=2880

dd if=dasher.bin of=dasher.img bs=512 count=1 conv=notrunc
