rm -f sokoban.bin sokoban.img

nasm -f bin sokoban.asm -o sokoban.bin

dd if=/dev/zero of=sokoban.img bs=512 count=2880

dd if=sokoban.bin of=sokoban.img bs=512 count=1 conv=notrunc
