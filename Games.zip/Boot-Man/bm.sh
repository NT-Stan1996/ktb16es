rm -f bm.bin bm.img

nasm -f bin bm.asm -o bm.bin

dd if=/dev/zero of=bm.img bs=512 count=2880

dd if=bm.bin of=bm.img bs=512 count=1 conv=notrunc