rm -f music.bin music.img

nasm -f bin music.asm -o music.bin

dd if=/dev/zero of=music.img bs=512 count=2880

dd if=music.bin of=music.img bs=512 count=1 conv=notrunc
