rm -f snake.bin snake.img

nasm -f bin snake.asm -o snake.bin

dd if=/dev/zero of=snake.img bs=512 count=2880

dd if=snake.bin of=snake.img bs=512 count=1 conv=notrunc
