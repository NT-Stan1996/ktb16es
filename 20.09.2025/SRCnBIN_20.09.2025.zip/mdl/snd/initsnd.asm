; Função corrigida para tocar beep de 732Hz - versão funcional para MBR
initsnd:
    pusha               ; Salvar todos registradores
    
    ; PROBLEMA 1: Primeiro deve habilitar o gate do PIT channel 2
    in al, 0x61         ; Ler estado atual da porta 0x61
    push ax             ; Salvar estado original
    or al, 1            ; Bit 0 = 1: conectar PIT channel 2 ao speaker
    out 0x61, al        ; Aplicar mudança ANTES de programar o PIT
    
    ; PROBLEMA 2: Configurar PIT Timer 2 corretamente
    mov al, 0xB6        ; 10110110b: Channel 2, LSB+MSB, Mode 3 (square wave)
    out 0x43, al        ; Comando para PIT
    
    ; PROBLEMA 3: Cálculo correto do divisor para 732Hz
    ; Fórmula: 1193182 / frequência = divisor
    ; 1193182 / 732 = 1630 (0x065E)
    mov ax, 1630        
    out 0x42, al        ; Enviar LSB primeiro
    mov al, ah          
    out 0x42, al        ; Depois MSB
    
    ; PROBLEMA 4: Agora habilitar o speaker propriamente
    in al, 0x61         ; Ler novamente
    or al, 2            ; Bit 1 = 1: habilitar speaker quando usando PIT
    out 0x61, al        ; Aplicar - agora ambos bits 0 e 1 estão em 1
    
    ; Delay calibrado para ~1 segundo
    mov cx, 0x8000      ; Contador otimizado
delay:  
    in al, 0x80         ; Port 0x80 delay (mais preciso que nop)
    loop delay          
    
    ; Desabilitar speaker (manter gate ativo mas desligar speaker)
    pop ax              ; Recuperar estado original
    out 0x61, al        ; Restaurar estado completo
    
    popa                ; Restaurar registradores
    ret